den=20
num=2453
if den==0:
    print("division by zero")
else:
    print("remainder = " + str( num % den))