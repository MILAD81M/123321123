x=50
y=6
if x>y :
    maximum=x
else:
    maximum=y
print(maximum)