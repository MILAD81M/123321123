x=40
y=10
if x>y:
    temp=x
    x=y
    y=temp
print("x=",x)
print("y=",y)