import math
n=10
for i in range(n+1):
    print(str(i)+' '+str(2*math.pi*i/n))
