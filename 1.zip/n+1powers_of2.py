power=1
n=10
for i in range(1,n+1):
    print(str(i)+' '+str(power))
    power *=2