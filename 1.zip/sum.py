n=154
total=0
for i in range (1,n+1):
    total+=1
print(total)